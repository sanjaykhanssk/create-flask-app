import os
secrectKey = lambda length :  os.urandom(length).hex()